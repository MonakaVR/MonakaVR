package dev.monaka.protocol.v3

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonNull
import com.google.gson.JsonObject
import com.google.gson.JsonPrimitive
import com.google.gson.Strictness
import com.google.gson.stream.JsonReader
import com.google.gson.stream.JsonToken
import java.io.StringReader
import java.math.BigDecimal
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.hypot

enum class ErrorCode {
    MalformedJson, InvalidUtf8, DuplicateKey, TooLarge, UnsupportedVersion,
    UnsupportedMessage, UnsupportedValue, MissingField, InvalidType,
    OutOfRange, InvalidQuaternion, InconsistentValidity
}

sealed interface DecodeResult {
    data class Success(val value: Envelope) : DecodeResult
    data class Failure(val code: ErrorCode, val message: String) : DecodeResult
}

sealed interface EncodeResult {
    data class Success(val value: ByteArray) : EncodeResult
    data class Failure(val code: ErrorCode, val message: String) : EncodeResult
}

internal val gson: Gson = GsonBuilder()
    .serializeNulls()
    .serializeSpecialFloatingPointValues()
    .disableHtmlEscaping()
    .create()

private const val WIRE_MAJOR = 3
private const val WIRE_MINOR = 0
private const val MAX_BYTES = 4096
private const val MAX_DEPTH = 16

private class Invalid(val code: ErrorCode, override val message: String) : RuntimeException(message)

private fun need(ok: Boolean, code: ErrorCode, path: String) {
    if (!ok) throw Invalid(code, path)
}

private fun fail(code: ErrorCode, path: String): Nothing = throw Invalid(code, path)

private fun JsonElement.number() = isJsonPrimitive && asJsonPrimitive.isNumber
private fun JsonElement.string() = isJsonPrimitive && asJsonPrimitive.isString
private fun JsonElement.bool() = isJsonPrimitive && asJsonPrimitive.isBoolean

private fun validString(value: String): Boolean {
    var index = 0
    while (index < value.length) {
        val ch = value[index++]
        if (Character.isHighSurrogate(ch)) {
            if (index == value.length || !Character.isLowSurrogate(value[index++])) return false
        } else if (Character.isLowSurrogate(ch)) {
            return false
        }
    }
    return true
}

private fun parse(reader: JsonReader, depth: Int = 0): JsonElement = when (reader.peek()) {
    JsonToken.BEGIN_OBJECT -> {
        need(depth < MAX_DEPTH, ErrorCode.MalformedJson, "depth exceeds $MAX_DEPTH")
        reader.beginObject()
        val obj = JsonObject()
        while (reader.hasNext()) {
            val key = reader.nextName()
            need(validString(key), ErrorCode.MalformedJson, "unpaired surrogate")
            need(!obj.has(key), ErrorCode.DuplicateKey, "duplicate object key")
            obj.add(key, parse(reader, depth + 1))
        }
        reader.endObject()
        obj
    }
    JsonToken.BEGIN_ARRAY -> {
        need(depth < MAX_DEPTH, ErrorCode.MalformedJson, "depth exceeds $MAX_DEPTH")
        reader.beginArray()
        val array = JsonArray()
        while (reader.hasNext()) array.add(parse(reader, depth + 1))
        reader.endArray()
        array
    }
    JsonToken.STRING -> {
        val value = reader.nextString()
        need(validString(value), ErrorCode.MalformedJson, "unpaired surrogate")
        JsonPrimitive(value)
    }
    JsonToken.NUMBER -> {
        val raw = reader.nextString()
        need(raw.toDouble().isFinite(), ErrorCode.OutOfRange, "nonfinite number")
        JsonPrimitive(BigDecimal(raw))
    }
    JsonToken.BOOLEAN -> JsonPrimitive(reader.nextBoolean())
    JsonToken.NULL -> {
        reader.nextNull()
        JsonNull.INSTANCE
    }
    else -> fail(ErrorCode.MalformedJson, "unexpected JSON token")
}

private fun validate(value: JsonElement, schema: JsonObject, path: String) {
    if (schema.has("\$ref")) {
        val ref = schema["\$ref"].asString.removePrefix("#/\$defs/")
        validate(value, definitions[ref].asJsonObject, path)
        when (ref) {
            "U63" -> need(value.asString.toLongOrNull() != null, ErrorCode.OutOfRange, path)
            "Id" -> need(value.asString.toByteArray(Charsets.UTF_8).size <= 96, ErrorCode.OutOfRange, path)
        }
        return
    }
    if (schema.has("anyOf")) {
        // All v3 unions are a concrete type followed by null.
        if (!value.isJsonNull) validate(value, schema["anyOf"].asJsonArray[0].asJsonObject, path)
        return
    }
    val type = schema["type"].asString
    val matchesType = when (type) {
        "object" -> value.isJsonObject
        "array" -> value.isJsonArray
        "string" -> value.string()
        "boolean" -> value.bool()
        "null" -> value.isJsonNull
        else -> value.number()
    }
    need(matchesType, ErrorCode.InvalidType, path)
    when (type) {
        "object" -> {
            val obj = value.asJsonObject
            for (required in schema["required"].asJsonArray) {
                val key = required.asString
                need(obj.has(key), ErrorCode.MissingField, "$path.$key")
            }
            for ((key, property) in schema["properties"].asJsonObject.entrySet()) {
                if (obj.has(key)) validate(obj[key], property.asJsonObject, "$path.$key")
            }
        }
        "array" -> {
            val array = value.asJsonArray
            if (schema.has("minItems")) need(array.size() >= schema["minItems"].asInt, ErrorCode.OutOfRange, path)
            if (schema.has("maxItems")) need(array.size() <= schema["maxItems"].asInt, ErrorCode.OutOfRange, path)
            for (item in array) validate(item, schema["items"].asJsonObject, "$path[]")
            if (schema.has("uniqueItems")) {
                need(array.toSet().size == array.size(), ErrorCode.InconsistentValidity, path)
            }
        }
        "string" -> {
            val str = value.asString
            need(validString(str), ErrorCode.InvalidUtf8, path)
            val length = str.codePointCount(0, str.length)
            if (schema.has("minLength")) need(length >= schema["minLength"].asInt, ErrorCode.OutOfRange, path)
            if (schema.has("maxLength")) need(length <= schema["maxLength"].asInt, ErrorCode.OutOfRange, path)
            if (schema.has("pattern")) {
                need(Regex(schema["pattern"].asString).matches(str), ErrorCode.OutOfRange, path)
            }
        }
        "number", "integer" -> {
            val number = value.asDouble
            need(number.isFinite(), ErrorCode.OutOfRange, path)
            if (type == "integer") need(floor(number) == number, ErrorCode.InvalidType, path)
            if (schema.has("minimum")) need(number >= schema["minimum"].asDouble, ErrorCode.OutOfRange, path)
            if (schema.has("maximum")) need(number <= schema["maximum"].asDouble, ErrorCode.OutOfRange, path)
        }
    }
    if (schema.has("enum")) {
        need(schema["enum"].asJsonArray.any { it == value }, ErrorCode.UnsupportedValue, path)
    }
    if (schema.has("const")) need(schema["const"] == value, ErrorCode.UnsupportedValue, path)
}

private enum class Message(val schemaName: String, val read: (JsonObject) -> Envelope) {
    OBSERVATION_POSE("TrackerObservation", ::readTrackerObservation),
    OBSERVATION_STATE("ObservationDeviceState", ::readObservationDeviceState),
    MTP_POSE("MtpPose", ::readMtpPose),
    MTP_STATE("MtpTrackerState", ::readMtpTrackerState),
}

private fun dispatch(value: JsonElement): Message {
    need(value.isJsonObject, ErrorCode.InvalidType, "envelope")
    val j = value.asJsonObject
    for (key in listOf("protocol", "type", "version")) need(j.has(key), ErrorCode.MissingField, key)
    need(j["protocol"].string() && j["type"].string() && j["version"].isJsonObject, ErrorCode.InvalidType, "dispatch")
    val version = j["version"].asJsonObject
    need(version.has("major"), ErrorCode.MissingField, "version.major")
    need(version["major"].number(), ErrorCode.InvalidType, "version.major")
    val major = version["major"].asDouble
    need(major.isFinite() && floor(major) == major, ErrorCode.InvalidType, "version.major")
    need(major in 0.0..65535.0, ErrorCode.OutOfRange, "version.major")
    need(major == WIRE_MAJOR.toDouble(), ErrorCode.UnsupportedVersion, "version.major")
    return when (j["protocol"].asString to j["type"].asString) {
        "monaka.observation" to "pose" -> Message.OBSERVATION_POSE
        "monaka.observation" to "device_state" -> Message.OBSERVATION_STATE
        "monaka.tracking" to "pose" -> Message.MTP_POSE
        "monaka.tracking" to "tracker_state" -> Message.MTP_STATE
        else -> fail(ErrorCode.UnsupportedMessage, "protocol/type")
    }
}

private fun validateSemantics(j: JsonObject, message: Message) {
    val sentAt = j["sent_at_ns"].asString.toLong()
    need(j["timestamp_ns"].asString.toLong() <= sentAt, ErrorCode.OutOfRange, "timestamp_ns > sent_at_ns")
    val caps = j["capabilities"].asJsonArray.map { it.asString }
    if (message != Message.MTP_POSE && !j["battery"].isJsonNull) {
        val battery = j["battery"].asJsonObject
        need(battery["timestamp_ns"].asString.toLong() <= sentAt, ErrorCode.OutOfRange, "battery timestamp > sent_at_ns")
        for ((field, capability) in listOf("fraction" to "battery_fraction", "charging" to "charging")) {
            if (!battery[field].isJsonNull) need(capability in caps, ErrorCode.InconsistentValidity, capability)
        }
    }
    if (message == Message.MTP_POSE) {
        need(j["input"].asJsonObject["source_id"] == j["source_id"], ErrorCode.InconsistentValidity, "input.source_id")
    }
    val modality = j["modality"].asString
    val tracking = j["tracking_state"].asString
    if (message == Message.OBSERVATION_STATE || message == Message.MTP_STATE) {
        if (j["presence"].asString == "absent" || tracking !in listOf("tracked", "degraded")) {
            need(modality == "none", ErrorCode.InconsistentValidity, "inactive state modality")
        }
        return
    }

    val validity = j["validity"].asJsonObject
    val position = validity["position"].asBoolean
    val orientation = validity["orientation"].asBoolean
    val modalityMatches = when (modality) {
        "full" -> position && orientation
        "rotation_only" -> !position && orientation
        else -> !position && !orientation
    }
    need(modalityMatches, ErrorCode.InconsistentValidity, "modality")
    val axes = listOf("position" to position, "orientation" to orientation)
    for ((axis, valid) in axes) {
        if (valid) need(!j[axis].isJsonNull && axis in caps, ErrorCode.InconsistentValidity, axis)
    }
    for (derivative in listOf("linear_velocity", "angular_velocity", "linear_acceleration")) {
        if (j.has(derivative) && !j[derivative].isJsonNull) {
            need(derivative in caps, ErrorCode.InconsistentValidity, derivative)
        }
    }
    if (orientation) {
        val norm = j["orientation"].asJsonArray.fold(0.0) { acc, item -> hypot(acc, item.asDouble) }
        val validNorm = if (message == Message.MTP_POSE) abs(norm - 1.0) <= 1e-5 else norm in 0.5..1.5
        need(validNorm, ErrorCode.InvalidQuaternion, "orientation norm")
    }
    if (message == Message.OBSERVATION_POSE) {
        val evidence = j["orientation_evidence"].asString
        need(orientation == (evidence != "none"), ErrorCode.InconsistentValidity, "orientation_evidence")
    }
    val trackingMatches = when (tracking) {
        "tracked" -> position && orientation
        "degraded" -> position || orientation
        else -> !position && !orientation
    }
    need(trackingMatches, ErrorCode.InconsistentValidity, "tracking_state")
    if (message == Message.MTP_POSE) {
        val confidence = j["confidence"].asJsonObject
        for ((axis, valid) in axes) {
            val confidenceValue = confidence[axis].asDouble
            need(if (valid) confidenceValue > 0.0 else confidenceValue == 0.0, ErrorCode.InconsistentValidity, "confidence.$axis")
        }
    }
}

private fun validateEnvelope(value: JsonElement): Message {
    val message = dispatch(value)
    val j = value.asJsonObject
    validate(j, definitions[message.schemaName].asJsonObject, "envelope")
    validateSemantics(j, message)
    return message
}

private fun finiteTree(value: JsonElement) {
    when {
        value.number() -> need(value.asDouble.isFinite(), ErrorCode.OutOfRange, "nonfinite number")
        value.isJsonArray -> value.asJsonArray.forEach(::finiteTree)
        value.isJsonObject -> value.asJsonObject.entrySet().forEach { finiteTree(it.value) }
    }
}

// Sort keys for reproducible encoding. Decode accepts any key order.
private fun sorted(value: JsonElement): JsonElement = when {
    value.isJsonObject -> JsonObject().also { out ->
        for ((key, child) in value.asJsonObject.entrySet().sortedBy { it.key }) out.add(key, sorted(child))
    }
    value.isJsonArray -> JsonArray().also { out -> value.asJsonArray.forEach { out.add(sorted(it)) } }
    else -> value
}

object MonakaCodec {
    @JvmStatic
    fun decodeEnvelope(data: ByteArray): DecodeResult = try {
        need(data.size <= MAX_BYTES, ErrorCode.TooLarge, "datagram exceeds $MAX_BYTES bytes")
        val text = try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(data))
                .toString()
        } catch (e: CharacterCodingException) {
            fail(ErrorCode.InvalidUtf8, "invalid UTF-8")
        }
        need(!text.startsWith('\uFEFF'), ErrorCode.MalformedJson, "BOM")
        val value = JsonReader(StringReader(text)).use { reader ->
            reader.strictness = Strictness.STRICT
            val parsed = parse(reader)
            need(reader.peek() == JsonToken.END_DOCUMENT, ErrorCode.MalformedJson, "trailing input")
            parsed
        }
        val message = validateEnvelope(value)
        DecodeResult.Success(message.read(value.asJsonObject))
    } catch (e: Invalid) {
        DecodeResult.Failure(e.code, e.message)
    } catch (e: Exception) {
        DecodeResult.Failure(ErrorCode.MalformedJson, e.message ?: "malformed JSON")
    }

    @JvmStatic
    fun encodeEnvelope(value: Envelope): EncodeResult = try {
        val j = when (value) {
            is TrackerObservation -> value.toJson()
            is ObservationDeviceState -> value.toJson()
            is MtpPose -> value.toJson()
            is MtpTrackerState -> value.toJson()
        }
        finiteTree(j)
        validateEnvelope(j)
        j["version"].asJsonObject.addProperty("minor", WIRE_MINOR)
        val bytes = gson.toJson(sorted(j)).toByteArray(Charsets.UTF_8)
        when (val checked = decodeEnvelope(bytes)) {
            is DecodeResult.Failure -> EncodeResult.Failure(checked.code, checked.message)
            is DecodeResult.Success -> EncodeResult.Success(bytes)
        }
    } catch (e: Invalid) {
        EncodeResult.Failure(e.code, e.message)
    } catch (e: Exception) {
        EncodeResult.Failure(ErrorCode.MalformedJson, e.message ?: "encode failed")
    }
}
