package dev.monaka.protocol.v3

import com.google.gson.JsonElement
import com.google.gson.JsonObject

private fun JsonObject.nonNull(name: String): JsonElement? = get(name)?.takeUnless { it.isJsonNull }

internal fun Version.toJson(): JsonObject = JsonObject().also { j ->
    j.add("major", gson.toJsonTree(major))
    j.add("minor", gson.toJsonTree(minor))
}

// Match the integral values checked by validation and used by the native codec.
internal fun readVersion(j: JsonObject): Version = Version(
    major = j.get("major").asDouble.toInt(),
    minor = j.get("minor").asDouble.toInt(),
)

internal fun Battery.toJson(): JsonObject = JsonObject().also { j ->
    j.add("fraction", gson.toJsonTree(fraction))
    j.add("charging", gson.toJsonTree(charging))
    j.add("timestamp_ns", gson.toJsonTree(timestamp_ns.toString()))
}

internal fun readBattery(j: JsonObject): Battery = Battery(
    fraction = j.nonNull("fraction")?.asDouble,
    charging = j.nonNull("charging")?.asBoolean,
    timestamp_ns = j.get("timestamp_ns").asLong,
)

internal fun Derivative.toJson(): JsonObject = JsonObject().also { j ->
    j.add("value", gson.toJsonTree(value))
    j.add("frame", gson.toJsonTree(frame))
    j.add("evidence", gson.toJsonTree(evidence))
}

internal fun readDerivative(j: JsonObject): Derivative = Derivative(
    value = j.get("value").asJsonArray.map { it.asDouble },
    frame = j.get("frame").asString,
    evidence = j.get("evidence").asString,
)

internal fun Validity.toJson(): JsonObject = JsonObject().also { j ->
    j.add("position", gson.toJsonTree(position))
    j.add("orientation", gson.toJsonTree(orientation))
}

internal fun readValidity(j: JsonObject): Validity = Validity(
    position = j.get("position").asBoolean,
    orientation = j.get("orientation").asBoolean,
)

internal fun Confidence.toJson(): JsonObject = JsonObject().also { j ->
    j.add("position", gson.toJsonTree(position))
    j.add("orientation", gson.toJsonTree(orientation))
}

internal fun readConfidence(j: JsonObject): Confidence = Confidence(
    position = j.get("position").asDouble,
    orientation = j.get("orientation").asDouble,
)

internal fun Input.toJson(): JsonObject = JsonObject().also { j ->
    j.add("source_id", gson.toJsonTree(source_id))
    j.add("device_id", gson.toJsonTree(device_id))
    j.add("session_id", gson.toJsonTree(session_id))
    j.add("sequence", gson.toJsonTree(sequence.toString()))
    j.add("orientation_evidence", gson.toJsonTree(orientation_evidence))
}

internal fun readInput(j: JsonObject): Input = Input(
    source_id = j.get("source_id").asString,
    device_id = j.get("device_id").asString,
    session_id = j.get("session_id").asString,
    sequence = j.get("sequence").asLong,
    orientation_evidence = j.get("orientation_evidence").asString,
)

internal fun TrackerObservation.toJson(): JsonObject = JsonObject().also { j ->
    j.add("version", version.toJson())
    j.add("source_id", gson.toJsonTree(source_id))
    j.add("session_id", gson.toJsonTree(session_id))
    j.add("clock_id", gson.toJsonTree(clock_id))
    j.add("sequence", gson.toJsonTree(sequence.toString()))
    j.add("timestamp_ns", gson.toJsonTree(timestamp_ns.toString()))
    j.add("sent_at_ns", gson.toJsonTree(sent_at_ns.toString()))
    j.add("timestamp_kind", gson.toJsonTree(timestamp_kind))
    j.add("device_id", gson.toJsonTree(device_id))
    j.add("position", gson.toJsonTree(position))
    j.add("orientation", gson.toJsonTree(orientation))
    j.add("validity", validity.toJson())
    j.add("orientation_evidence", gson.toJsonTree(orientation_evidence))
    j.add("linear_velocity", linear_velocity?.toJson())
    j.add("angular_velocity", angular_velocity?.toJson())
    j.add("linear_acceleration", linear_acceleration?.toJson())
    j.add("tracking_state", gson.toJsonTree(tracking_state))
    j.addProperty("convention", convention)
    j.add("capabilities", gson.toJsonTree(capabilities))
    j.add("modality", gson.toJsonTree(modality))
    j.add("battery", battery?.toJson())
    j.addProperty("protocol", "monaka.observation")
    j.addProperty("type", "pose")
}

internal fun readTrackerObservation(j: JsonObject): TrackerObservation = TrackerObservation(
    version = readVersion(j.get("version").asJsonObject),
    source_id = j.get("source_id").asString,
    session_id = j.get("session_id").asString,
    clock_id = j.get("clock_id").asString,
    sequence = j.get("sequence").asLong,
    timestamp_ns = j.get("timestamp_ns").asLong,
    sent_at_ns = j.get("sent_at_ns").asLong,
    timestamp_kind = j.get("timestamp_kind").asString,
    device_id = j.get("device_id").asString,
    position = j.nonNull("position")?.asJsonArray?.map { it.asDouble },
    orientation = j.nonNull("orientation")?.asJsonArray?.map { it.asDouble },
    validity = readValidity(j.get("validity").asJsonObject),
    orientation_evidence = j.get("orientation_evidence").asString,
    linear_velocity = j.nonNull("linear_velocity")?.asJsonObject?.let(::readDerivative),
    angular_velocity = j.nonNull("angular_velocity")?.asJsonObject?.let(::readDerivative),
    linear_acceleration = j.nonNull("linear_acceleration")?.asJsonObject?.let(::readDerivative),
    tracking_state = j.get("tracking_state").asString,
    convention = j.get("convention").asString,
    capabilities = j.get("capabilities").asJsonArray.map { it.asString },
    modality = j.get("modality").asString,
    battery = j.nonNull("battery")?.asJsonObject?.let(::readBattery),
)

internal fun ObservationDeviceState.toJson(): JsonObject = JsonObject().also { j ->
    j.add("version", version.toJson())
    j.add("source_id", gson.toJsonTree(source_id))
    j.add("session_id", gson.toJsonTree(session_id))
    j.add("clock_id", gson.toJsonTree(clock_id))
    j.add("sequence", gson.toJsonTree(sequence.toString()))
    j.add("timestamp_ns", gson.toJsonTree(timestamp_ns.toString()))
    j.add("sent_at_ns", gson.toJsonTree(sent_at_ns.toString()))
    j.add("timestamp_kind", gson.toJsonTree(timestamp_kind))
    j.add("device_id", gson.toJsonTree(device_id))
    j.add("presence", gson.toJsonTree(presence))
    j.add("tracking_state", gson.toJsonTree(tracking_state))
    j.addProperty("convention", convention)
    j.add("capabilities", gson.toJsonTree(capabilities))
    j.add("modality", gson.toJsonTree(modality))
    j.add("battery", battery?.toJson())
    j.addProperty("protocol", "monaka.observation")
    j.addProperty("type", "device_state")
}

internal fun readObservationDeviceState(j: JsonObject): ObservationDeviceState = ObservationDeviceState(
    version = readVersion(j.get("version").asJsonObject),
    source_id = j.get("source_id").asString,
    session_id = j.get("session_id").asString,
    clock_id = j.get("clock_id").asString,
    sequence = j.get("sequence").asLong,
    timestamp_ns = j.get("timestamp_ns").asLong,
    sent_at_ns = j.get("sent_at_ns").asLong,
    timestamp_kind = j.get("timestamp_kind").asString,
    device_id = j.get("device_id").asString,
    presence = j.get("presence").asString,
    tracking_state = j.get("tracking_state").asString,
    convention = j.get("convention").asString,
    capabilities = j.get("capabilities").asJsonArray.map { it.asString },
    modality = j.get("modality").asString,
    battery = j.nonNull("battery")?.asJsonObject?.let(::readBattery),
)

internal fun MtpPose.toJson(): JsonObject = JsonObject().also { j ->
    j.add("version", version.toJson())
    j.add("source_id", gson.toJsonTree(source_id))
    j.add("session_id", gson.toJsonTree(session_id))
    j.add("clock_id", gson.toJsonTree(clock_id))
    j.add("sequence", gson.toJsonTree(sequence.toString()))
    j.add("timestamp_ns", gson.toJsonTree(timestamp_ns.toString()))
    j.add("sent_at_ns", gson.toJsonTree(sent_at_ns.toString()))
    j.add("timestamp_kind", gson.toJsonTree(timestamp_kind))
    j.add("tracker_id", gson.toJsonTree(tracker_id))
    j.add("position", gson.toJsonTree(position))
    j.add("orientation", gson.toJsonTree(orientation))
    j.add("validity", validity.toJson())
    j.add("linear_velocity", gson.toJsonTree(linear_velocity))
    j.add("angular_velocity", gson.toJsonTree(angular_velocity))
    j.add("linear_acceleration", gson.toJsonTree(linear_acceleration))
    j.add("confidence", confidence.toJson())
    j.add("tracking_state", gson.toJsonTree(tracking_state))
    j.addProperty("convention", convention)
    j.add("capabilities", gson.toJsonTree(capabilities))
    j.add("modality", gson.toJsonTree(modality))
    j.add("publisher_id", gson.toJsonTree(publisher_id))
    j.add("input", input.toJson())
    j.addProperty("protocol", "monaka.tracking")
    j.addProperty("type", "pose")
}

internal fun readMtpPose(j: JsonObject): MtpPose = MtpPose(
    version = readVersion(j.get("version").asJsonObject),
    source_id = j.get("source_id").asString,
    session_id = j.get("session_id").asString,
    clock_id = j.get("clock_id").asString,
    sequence = j.get("sequence").asLong,
    timestamp_ns = j.get("timestamp_ns").asLong,
    sent_at_ns = j.get("sent_at_ns").asLong,
    timestamp_kind = j.get("timestamp_kind").asString,
    tracker_id = j.get("tracker_id").asString,
    position = j.nonNull("position")?.asJsonArray?.map { it.asDouble },
    orientation = j.nonNull("orientation")?.asJsonArray?.map { it.asDouble },
    validity = readValidity(j.get("validity").asJsonObject),
    linear_velocity = j.nonNull("linear_velocity")?.asJsonArray?.map { it.asDouble },
    angular_velocity = j.nonNull("angular_velocity")?.asJsonArray?.map { it.asDouble },
    linear_acceleration = j.nonNull("linear_acceleration")?.asJsonArray?.map { it.asDouble },
    confidence = readConfidence(j.get("confidence").asJsonObject),
    tracking_state = j.get("tracking_state").asString,
    convention = j.get("convention").asString,
    capabilities = j.get("capabilities").asJsonArray.map { it.asString },
    modality = j.get("modality").asString,
    publisher_id = j.get("publisher_id").asString,
    input = readInput(j.get("input").asJsonObject),
)

internal fun MtpTrackerState.toJson(): JsonObject = JsonObject().also { j ->
    j.add("version", version.toJson())
    j.add("source_id", gson.toJsonTree(source_id))
    j.add("session_id", gson.toJsonTree(session_id))
    j.add("clock_id", gson.toJsonTree(clock_id))
    j.add("sequence", gson.toJsonTree(sequence.toString()))
    j.add("timestamp_ns", gson.toJsonTree(timestamp_ns.toString()))
    j.add("sent_at_ns", gson.toJsonTree(sent_at_ns.toString()))
    j.add("timestamp_kind", gson.toJsonTree(timestamp_kind))
    j.add("tracker_id", gson.toJsonTree(tracker_id))
    j.add("presence", gson.toJsonTree(presence))
    j.add("tracking_state", gson.toJsonTree(tracking_state))
    j.addProperty("convention", convention)
    j.add("capabilities", gson.toJsonTree(capabilities))
    j.add("modality", gson.toJsonTree(modality))
    j.add("publisher_id", gson.toJsonTree(publisher_id))
    j.add("battery", battery?.toJson())
    j.addProperty("protocol", "monaka.tracking")
    j.addProperty("type", "tracker_state")
}

internal fun readMtpTrackerState(j: JsonObject): MtpTrackerState = MtpTrackerState(
    version = readVersion(j.get("version").asJsonObject),
    source_id = j.get("source_id").asString,
    session_id = j.get("session_id").asString,
    clock_id = j.get("clock_id").asString,
    sequence = j.get("sequence").asLong,
    timestamp_ns = j.get("timestamp_ns").asLong,
    sent_at_ns = j.get("sent_at_ns").asLong,
    timestamp_kind = j.get("timestamp_kind").asString,
    tracker_id = j.get("tracker_id").asString,
    presence = j.get("presence").asString,
    tracking_state = j.get("tracking_state").asString,
    convention = j.get("convention").asString,
    capabilities = j.get("capabilities").asJsonArray.map { it.asString },
    modality = j.get("modality").asString,
    publisher_id = j.get("publisher_id").asString,
    battery = j.nonNull("battery")?.asJsonObject?.let(::readBattery),
)
