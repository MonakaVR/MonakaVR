package dev.monaka.protocol.v3

import java.io.File

object Runner {
    @JvmStatic
    fun main(args: Array<String>) {
        val model = when (val decoded = MonakaCodec.decodeEnvelope(File(args[0]).readBytes())) {
            is DecodeResult.Success -> decoded.value
            is DecodeResult.Failure -> {
                println("ERROR:${decoded.code}")
                return
            }
        }
        when (args.getOrNull(1)) {
            "--self-test" -> selfTest(model as TrackerObservation)
            "--version-minor" -> println(
                when (model) {
                    is TrackerObservation -> model.version.minor
                    is ObservationDeviceState -> model.version.minor
                    is MtpPose -> model.version.minor
                    is MtpTrackerState -> model.version.minor
                },
            )
            else -> when (val encoded = MonakaCodec.encodeEnvelope(model)) {
                is EncodeResult.Success -> println(encoded.value.toString(Charsets.UTF_8))
                is EncodeResult.Failure -> println("ERROR:${encoded.code}")
            }
        }
    }

    private fun selfTest(pose: TrackerObservation) {
        for (number in listOf(Double.NaN, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY)) {
            val result = MonakaCodec.encodeEnvelope(pose.copy(position = listOf(number, 0.0, 0.0)))
            check(result is EncodeResult.Failure && result.code == ErrorCode.OutOfRange)
        }
        val badUtf16 = MonakaCodec.encodeEnvelope(pose.copy(source_id = "\uD800"))
        check(badUtf16 is EncodeResult.Failure && badUtf16.code == ErrorCode.InvalidUtf8)
        val badSequence = MonakaCodec.encodeEnvelope(pose.copy(sequence = -1))
        check(badSequence is EncodeResult.Failure && badSequence.code == ErrorCode.OutOfRange)
        println("PASS JVM nonfinite model, invalid UTF-16, negative U63 checks")
    }
}
