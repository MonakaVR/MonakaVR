#include "monaka/protocol/v3/codec.hpp"
#include "nlohmann/json.hpp"

#include <algorithm>
#include <cmath>
#include <regex>
#include <set>
#include <stdexcept>
#include <utility>

namespace monaka::protocol::v3 {
using json = nlohmann::json;
#include "models_json.inc"

namespace {
#include "schema.inc"

constexpr std::size_t MaxDatagramSize = 4096;
constexpr int MaxDepth = 16;
constexpr std::uint16_t WireMajor = 3;
constexpr std::uint16_t WireMinor = 0;

struct Failure {
    ErrorCode code;
    std::string message;
};

[[noreturn]] void fail(ErrorCode code, const std::string& message) {
    throw Failure{code, message};
}

void require(bool condition, ErrorCode code, const std::string& message) {
    if (!condition) fail(code, message);
}

bool validUtf8(const std::uint8_t* data, std::size_t size) {
    for (std::size_t i = 0; i < size;) {
        const auto first = data[i++];
        if (first < 0x80) continue;

        unsigned codepoint, count, minimum;
        if (first >= 0xc2 && first <= 0xdf) {
            codepoint = first & 31;
            count = 1;
            minimum = 0x80;
        } else if (first >= 0xe0 && first <= 0xef) {
            codepoint = first & 15;
            count = 2;
            minimum = 0x800;
        } else if (first >= 0xf0 && first <= 0xf4) {
            codepoint = first & 7;
            count = 3;
            minimum = 0x10000;
        } else {
            return false;
        }
        if (size - i < count) return false;
        for (unsigned k = 0; k < count; ++k) {
            const auto continuation = data[i++];
            if ((continuation & 0xc0) != 0x80) return false;
            codepoint = (codepoint << 6) | (continuation & 63);
        }
        if (codepoint < minimum || codepoint > 0x10ffff ||
            (codepoint >= 0xd800 && codepoint <= 0xdfff)) return false;
    }
    return true;
}

void validateString(const std::string& text, const json& definition, const std::string& path) {
    // JSON Schema lengths count code points. The Id reference also limits bytes.
    const auto length = static_cast<std::size_t>(std::count_if(text.begin(), text.end(), [](unsigned char c) {
        return (c & 0xc0) != 0x80;
    }));
    require(length >= definition.value("minLength", std::size_t{0}), ErrorCode::OutOfRange, path);
    if (definition.contains("maxLength")) {
        require(length <= definition.at("maxLength").get<std::size_t>(), ErrorCode::OutOfRange, path);
    }
    if (!definition.contains("pattern")) return;

    const auto pattern = definition.at("pattern").get<std::string>();
    if (pattern.find("001f") == std::string::npos) {
        require(std::regex_match(text, std::regex(pattern)), ErrorCode::OutOfRange, path);
        return;
    }
    // The Id pattern excludes C0 and C1 controls. Match their UTF-8 bytes explicitly.
    for (std::size_t i = 0; i < text.size(); ++i) {
        const auto c = static_cast<unsigned char>(text[i]);
        const auto next = i + 1 < text.size() ? static_cast<unsigned char>(text[i + 1]) : 0;
        require(c >= 32 && c != 127 && !(c == 0xc2 && next >= 0x80 && next <= 0x9f),
                ErrorCode::OutOfRange, path);
    }
}

void validate(const json& value, const json& definition, const std::string& path) {
    if (definition.contains("$ref")) {
        const auto name = definition.at("$ref").get<std::string>().substr(8);
        validate(value, schema.at("$defs").at(name), path);
        if (name == "U63") {
            const auto& text = value.get_ref<const std::string&>();
            require(text.size() < 19 || text <= "9223372036854775807", ErrorCode::OutOfRange, path);
        }
        if (name == "Id") {
            require(value.get_ref<const std::string&>().size() <= 96, ErrorCode::OutOfRange, path);
        }
        return;
    }
    if (definition.contains("anyOf")) {
        if (!value.is_null()) validate(value, definition.at("anyOf").at(0), path);
        return;
    }

    const auto type = definition.value("type", "");
    if (type == "object") {
        require(value.is_object(), ErrorCode::InvalidType, path);
        for (const auto& requiredKey : definition.at("required")) {
            const auto& key = requiredKey.get_ref<const std::string&>();
            require(value.contains(key), ErrorCode::MissingField, path + "." + key);
        }
        for (const auto& property : definition.at("properties").items()) {
            if (value.contains(property.key())) {
                validate(value.at(property.key()), property.value(), path + "." + property.key());
            }
        }
    } else if (type == "array") {
        require(value.is_array(), ErrorCode::InvalidType, path);
        if (definition.contains("minItems")) {
            require(value.size() >= definition.at("minItems").get<std::size_t>(), ErrorCode::OutOfRange, path);
        }
        if (definition.contains("maxItems")) {
            require(value.size() <= definition.at("maxItems").get<std::size_t>(), ErrorCode::OutOfRange, path);
        }
        for (const auto& item : value) validate(item, definition.at("items"), path + "[]");
        if (definition.value("uniqueItems", false)) {
            for (std::size_t i = 0; i < value.size(); ++i) {
                for (std::size_t k = 0; k < i; ++k) {
                    require(value[i] != value[k], ErrorCode::InconsistentValidity, path);
                }
            }
        }
    } else if (type == "string") {
        require(value.is_string(), ErrorCode::InvalidType, path);
        validateString(value.get_ref<const std::string&>(), definition, path);
    } else if (type == "boolean") {
        require(value.is_boolean(), ErrorCode::InvalidType, path);
    } else if (type == "number" || type == "integer") {
        require(value.is_number(), ErrorCode::InvalidType, path);
        const double number = value.get<double>();
        require(std::isfinite(number), ErrorCode::OutOfRange, path);
        if (type == "integer") require(std::floor(number) == number, ErrorCode::InvalidType, path);
        if (definition.contains("minimum")) {
            require(number >= definition.at("minimum").get<double>(), ErrorCode::OutOfRange, path);
        }
        if (definition.contains("maximum")) {
            require(number <= definition.at("maximum").get<double>(), ErrorCode::OutOfRange, path);
        }
    } else if (type == "null") {
        require(value.is_null(), ErrorCode::InvalidType, path);
    }

    if (definition.contains("enum")) {
        const auto& choices = definition.at("enum");
        require(std::find(choices.begin(), choices.end(), value) != choices.end(), ErrorCode::UnsupportedValue, path);
    }
    if (definition.contains("const")) require(value == definition.at("const"), ErrorCode::UnsupportedValue, path);
}

const char* dispatch(const json& value) {
    require(value.is_object(), ErrorCode::InvalidType, "envelope");
    for (const auto* key : {"protocol", "type", "version"}) {
        require(value.contains(key), ErrorCode::MissingField, key);
    }
    const auto& protocol = value.at("protocol");
    const auto& type = value.at("type");
    const auto& version = value.at("version");
    require(protocol.is_string() && type.is_string() && version.is_object(), ErrorCode::InvalidType, "dispatch");
    require(version.contains("major"), ErrorCode::MissingField, "version.major");
    require(version.at("major").is_number(), ErrorCode::InvalidType, "version.major");
    const double major = version.at("major").get<double>();
    require(std::isfinite(major) && std::floor(major) == major, ErrorCode::InvalidType, "version.major");
    require(major >= 0 && major <= 65535, ErrorCode::OutOfRange, "version.major");
    require(major == WireMajor, ErrorCode::UnsupportedVersion, "version.major");

    if (protocol == "monaka.observation" && type == "pose") return "TrackerObservation";
    if (protocol == "monaka.observation" && type == "device_state") return "ObservationDeviceState";
    if (protocol == "monaka.tracking" && type == "pose") return "MtpPose";
    if (protocol == "monaka.tracking" && type == "tracker_state") return "MtpTrackerState";
    fail(ErrorCode::UnsupportedMessage, "protocol/type");
}

void validateSemantics(const json& value) {
    const auto timestamp = [](const json& number) { return std::stoll(number.get<std::string>()); };
    require(timestamp(value.at("timestamp_ns")) <= timestamp(value.at("sent_at_ns")),
            ErrorCode::OutOfRange, "timestamp_ns > sent_at_ns");
    const auto& capabilities = value.at("capabilities");
    const auto hasCapability = [&](const char* name) {
        return std::find(capabilities.begin(), capabilities.end(), name) != capabilities.end();
    };
    const bool pose = value.at("type") == "pose";
    const bool mtp = value.at("protocol") == "monaka.tracking";
    if ((!pose || !mtp) && !value.at("battery").is_null()) {
        const auto& battery = value.at("battery");
        require(timestamp(battery.at("timestamp_ns")) <= timestamp(value.at("sent_at_ns")),
                ErrorCode::OutOfRange, "battery timestamp > sent_at_ns");
        for (auto pair : {std::pair{"fraction", "battery_fraction"}, std::pair{"charging", "charging"}}) {
            if (!battery.at(pair.first).is_null()) {
                require(hasCapability(pair.second), ErrorCode::InconsistentValidity, pair.second);
            }
        }
    }

    const auto& modality = value.at("modality");
    const auto& state = value.at("tracking_state");
    if (!pose) {
        if (value.at("presence") == "absent" || (state != "tracked" && state != "degraded")) {
            require(modality == "none", ErrorCode::InconsistentValidity, "inactive state modality");
        }
        return;
    }
    if (mtp) {
        require(value.at("input").at("source_id") == value.at("source_id"),
                ErrorCode::InconsistentValidity, "input.source_id");
    }

    const auto& validity = value.at("validity");
    const bool positionValid = validity.at("position").get<bool>();
    const bool orientationValid = validity.at("orientation").get<bool>();
    require(modality == "full" ? positionValid && orientationValid :
            modality == "rotation_only" ? !positionValid && orientationValid : !positionValid && !orientationValid,
            ErrorCode::InconsistentValidity, "modality");
    for (auto pair : {std::pair{"position", positionValid}, std::pair{"orientation", orientationValid}}) {
        if (pair.second) {
            require(!value.at(pair.first).is_null() && hasCapability(pair.first),
                    ErrorCode::InconsistentValidity, pair.first);
        }
    }
    for (const auto* name : {"linear_velocity", "angular_velocity", "linear_acceleration"}) {
        if (value.contains(name) && !value.at(name).is_null()) {
            require(hasCapability(name), ErrorCode::InconsistentValidity, name);
        }
    }
    if (orientationValid) {
        double norm = 0;
        for (const auto& component : value.at("orientation")) norm = std::hypot(norm, component.get<double>());
        require(mtp ? std::abs(norm - 1) <= 1e-5 : norm >= 0.5 && norm <= 1.5,
                ErrorCode::InvalidQuaternion, "orientation norm");
    }
    if (!mtp) {
        const auto& evidence = value.at("orientation_evidence");
        require(orientationValid ? evidence != "none" : evidence == "none",
                ErrorCode::InconsistentValidity, "orientation_evidence");
    }
    require(state == "tracked" ? positionValid && orientationValid :
            state == "degraded" ? positionValid || orientationValid : !positionValid && !orientationValid,
            ErrorCode::InconsistentValidity, "tracking_state");
    if (mtp) {
        const auto& confidence = value.at("confidence");
        require(positionValid ? confidence.at("position").get<double>() > 0 : confidence.at("position") == 0,
                ErrorCode::InconsistentValidity, "confidence.position");
        require(orientationValid ? confidence.at("orientation").get<double>() > 0 : confidence.at("orientation") == 0,
                ErrorCode::InconsistentValidity, "confidence.orientation");
    }
}

void requireFinite(const json& value) {
    // JSON serialization maps NaN to null. Reject nonfinite model values before writing.
    if (value.is_number_float()) {
        require(std::isfinite(value.get<double>()), ErrorCode::OutOfRange, "nonfinite number");
    } else if (value.is_structured()) {
        for (const auto& item : value) requireFinite(item);
    }
}
}

const char* ErrorCodeName(ErrorCode code) noexcept {
    switch (code) {
    case ErrorCode::MalformedJson: return "MalformedJson";
    case ErrorCode::InvalidUtf8: return "InvalidUtf8";
    case ErrorCode::DuplicateKey: return "DuplicateKey";
    case ErrorCode::TooLarge: return "TooLarge";
    case ErrorCode::UnsupportedVersion: return "UnsupportedVersion";
    case ErrorCode::UnsupportedMessage: return "UnsupportedMessage";
    case ErrorCode::UnsupportedValue: return "UnsupportedValue";
    case ErrorCode::MissingField: return "MissingField";
    case ErrorCode::InvalidType: return "InvalidType";
    case ErrorCode::OutOfRange: return "OutOfRange";
    case ErrorCode::InvalidQuaternion: return "InvalidQuaternion";
    case ErrorCode::InconsistentValidity: return "InconsistentValidity";
    }
    return "MalformedJson";
}

bool DecodeEnvelope(const std::uint8_t* data, std::size_t size, Envelope& out, Error& error) {
    try {
        require(size <= MaxDatagramSize, ErrorCode::TooLarge, "datagram exceeds 4096 bytes");
        require(data != nullptr || size == 0, ErrorCode::MalformedJson, "null data");
        require(validUtf8(data, size), ErrorCode::InvalidUtf8, "invalid UTF-8");
        require(!(size >= 3 && data[0] == 0xef && data[1] == 0xbb && data[2] == 0xbf),
                ErrorCode::MalformedJson, "BOM");
        require(size > 0, ErrorCode::MalformedJson, "empty input");
        const auto* end = data + size;
        // The JSON lexer treats a raw NUL as end of input, even in a sized buffer.
        require(std::find(data, end, std::uint8_t{0}) == end, ErrorCode::MalformedJson, "raw NUL in JSON");

        std::vector<std::set<std::string>> objects;
        int depth = 0;
        const auto onParse = [&](int, json::parse_event_t event, json& parsed) {
            using Event = json::parse_event_t;
            if (event == Event::object_start || event == Event::array_start) {
                require(++depth <= MaxDepth, ErrorCode::MalformedJson, "depth exceeds 16");
            }
            if (event == Event::object_start) objects.emplace_back();
            if (event == Event::key) {
                require(objects.back().insert(parsed.get<std::string>()).second, ErrorCode::DuplicateKey,
                        "duplicate object key");
            }
            if (event == Event::object_end) objects.pop_back();
            if (event == Event::object_end || event == Event::array_end) --depth;
            return true;
        };
        const auto value = json::parse(data, end, onParse);
        const std::string name = dispatch(value);
        validate(value, schema.at("$defs").at(name), "envelope");
        validateSemantics(value);

        Envelope result;
        if (name == "TrackerObservation") result = value.get<TrackerObservation>();
        else if (name == "ObservationDeviceState") result = value.get<ObservationDeviceState>();
        else if (name == "MtpPose") result = value.get<MtpPose>();
        else if (name == "MtpTrackerState") result = value.get<MtpTrackerState>();
        out = std::move(result);
        error.message.clear();
        return true;
    } catch (const Failure& failure) {
        error = {failure.code, failure.message};
    } catch (const json::out_of_range& exception) {
        error = {ErrorCode::OutOfRange, exception.what()};
    } catch (const std::exception& exception) {
        error = {ErrorCode::MalformedJson, exception.what()};
    }
    return false;
}

bool EncodeEnvelope(const Envelope& value, std::string& utf8, Error& error) {
    try {
        json object = std::visit([](const auto& message) { return json(message); }, value);
        requireFinite(object);
        const auto* name = dispatch(object);
        validate(object, schema.at("$defs").at(name), "envelope");
        validateSemantics(object);
        object.at("version").at("minor") = WireMinor;
        auto encoded = object.dump();

        Envelope checked;
        if (!DecodeEnvelope(reinterpret_cast<const std::uint8_t*>(encoded.data()), encoded.size(), checked, error)) {
            return false;
        }
        utf8 = std::move(encoded);
        error.message.clear();
        return true;
    } catch (const Failure& failure) {
        error = {failure.code, failure.message};
    } catch (const json::type_error& exception) {
        error = {ErrorCode::InvalidUtf8, exception.what()};
    } catch (const std::exception& exception) {
        error = {ErrorCode::MalformedJson, exception.what()};
    }
    return false;
}
}
