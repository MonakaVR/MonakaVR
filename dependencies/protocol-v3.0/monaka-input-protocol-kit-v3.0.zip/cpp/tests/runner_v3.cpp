#include "monaka/protocol/v3/codec.hpp"

#include <fstream>
#include <iostream>
#include <iterator>
#include <limits>
#include <stdexcept>
#include <string_view>

namespace {
using namespace monaka::protocol::v3;

constexpr auto Sentinel = "unchanged sentinel";

void check(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

bool decode(std::string_view bytes, Envelope& message, Error& error) {
    return DecodeEnvelope(reinterpret_cast<const std::uint8_t*>(bytes.data()), bytes.size(), message, error);
}

Envelope sentinelMessage() {
    MtpTrackerState state;
    state.source_id = Sentinel;
    return state;
}

void checkUnchanged(const Envelope& message) {
    const auto* state = std::get_if<MtpTrackerState>(&message);
    check(state && state->source_id == Sentinel, "failed decode changed the output model");
}

void selfTest() {
    auto message = sentinelMessage();
    Error error;
    check(!DecodeEnvelope(nullptr, 0, message, error) && error.code == ErrorCode::MalformedJson,
          "empty decode returned the wrong error");
    checkUnchanged(message);

    const auto extension = R"({"protocol":"monaka.observation","type":"device_state","version":{"major":3,"minor":65535},
        "source_id":"source","session_id":"00000000-0000-0000-0000-000000000001",
        "clock_id":"00000000-0000-0000-0000-000000000002","sequence":"0","timestamp_ns":"0","sent_at_ns":"0",
        "timestamp_kind":"sample","device_id":"device","presence":"present","tracking_state":"lost",
        "convention":"source_axes","capabilities":[],"modality":"none","battery":null,
        "coordinate_space":["\u0000"],"mapping_revision":"ignored","input":false})";
    std::string trailing(extension);
    trailing.push_back('\0');
    trailing += "{}";
    check(!decode(trailing, message, error) && error.code == ErrorCode::MalformedJson,
          "decode accepted trailing bytes after a raw NUL");
    checkUnchanged(message);
    check(decode(extension, message, error), "future minor or an unknown property was rejected");
    const auto* state = std::get_if<ObservationDeviceState>(&message);
    check(state && state->version.major == 3 && state->version.minor == 65535 && state->convention == "source_axes",
          "decode failed to retain convention and incoming version");

    std::string encoded;
    check(EncodeEnvelope(message, encoded, error), "valid message failed to encode");
    check(encoded.find("coordinate_space") == std::string::npos &&
          encoded.find("mapping_revision") == std::string::npos &&
          encoded.find("\"input\"") == std::string::npos, "encode retained unknown properties");
    check(decode(encoded, message, error) && std::get<ObservationDeviceState>(message).version.minor == 0,
          "encode did not use wire 3.0");

    TrackerObservation observation;
    encoded = Sentinel;
    for (const auto component : {std::numeric_limits<double>::infinity(), std::numeric_limits<double>::quiet_NaN()}) {
        observation.position = Vec3{component, 0, 0};
        check(!EncodeEnvelope(observation, encoded, error) && error.code == ErrorCode::OutOfRange,
              "encode did not reject a nonfinite diagnostic component");
        check(encoded == Sentinel, "failed encode changed the output bytes");
    }
    std::cout << "PASS C++ v3 framing, atomicity, future minor, extensions and nonfinite model checks\n";
}
}

int main(int argc, char** argv) {
    if (argc != 2 && argc != 3) return 2;
    if (std::string_view(argv[1]) == "--self-test") {
        selfTest();
        return 0;
    }

    std::ifstream input(argv[1], std::ios::binary);
    if (!input) return 2;
    const std::string bytes((std::istreambuf_iterator<char>(input)), {});
    if (input.bad()) return 2;
    auto message = sentinelMessage();
    Error error;
    if (!decode(bytes, message, error)) {
        checkUnchanged(message);
        std::cout << "ERROR:" << ErrorCodeName(error.code) << '\n';
        return 0;
    }
    if (argc == 3 && std::string_view(argv[2]) == "--version-minor") {
        std::cout << std::visit([](const auto& value) { return value.version.minor; }, message) << '\n';
        return 0;
    }
    std::string encoded;
    if (!EncodeEnvelope(message, encoded, error)) {
        std::cout << "ERROR:" << ErrorCodeName(error.code) << '\n';
        return 0;
    }
    std::cout << encoded << '\n';
}
