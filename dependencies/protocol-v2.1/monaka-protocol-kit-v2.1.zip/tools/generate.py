"""Generate schema and typed bindings. Run --check to reject generated drift."""
import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CHECK = argparse.ArgumentParser()
CHECK.add_argument('--check', action='store_true')
CHECK.add_argument('--wire-major', type=int, choices=[1, 2], default=1)
CHECK.add_argument('--wire-minor', type=int, choices=[0, 1], default=0)
args = CHECK.parse_args()
checking = args.check
v2 = args.wire_major == 2
if args.wire_minor and not v2: CHECK.error("minor 1 requires major 2")

def put(name, content):
    if v2:
        content = content.rstrip() + '\n'
        name = name.replace('/v1/', '/v2/')
        if name.startswith('schema/'): name = name.replace('schema/', 'schema/v2/', 1)
        if name.startswith('cpp/src/'): name = name.replace('cpp/src/', 'cpp/src/v2/', 1)
        content = content.replace('namespace monaka::protocol::v1', 'namespace monaka::protocol::v2').replace('package dev.monaka.protocol.v1', 'package dev.monaka.protocol.v2')
    path = ROOT / name
    if checking:
        if path.read_text(encoding='utf-8') != content: raise RuntimeError(f'generated drift: {name}')
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding='utf-8', newline='\n')

task = (ROOT / 'docs/codex/Task1_MonakaProtocol.md').read_text(encoding='utf-8')
c1 = task.split('<!-- BEGIN COMMON C1 -->\n')[1].split('<!-- END COMMON C1 -->')[0]
assert hashlib.sha256(c1.encode()).hexdigest() == '3a76435c8b25b3975028f9a83c4dc3d1e3848806c9608d885f5bba74a1198ed3'
if not v2: put('docs/C1.md', c1)
else: c1 = (ROOT / 'docs/C2.md').read_text(encoding='utf-8')

def enum(*values): return {'type': 'string', 'enum': list(values)}
def ref(name): return {'$ref': '#/$defs/' + name}
def nullable(value): return {'anyOf': [value, {'type': 'null'}]}
def obj(fields):
    return {'type': 'object', 'properties': {k.rstrip('?'): v for k, v in fields.items()},
            'required': [k for k in fields if not k.endswith('?')], 'additionalProperties': True}

defs = {
    'Id': {'type':'string', 'minLength':1, 'maxLength':96, 'pattern':r'^[^\u0000-\u001f\u007f-\u009f]+$'},
    'Uuid': {'type':'string','pattern':r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'},
    'U63': {'type':'string','pattern':r'^(0|[1-9][0-9]*)$', 'maxLength':19},
    'UInt32': {'type':'integer','minimum':0,'maximum':4294967295},
    'UInt16': {'type':'integer','minimum':0,'maximum':65535},
    'Fraction': {'type':'number','minimum':0,'maximum':1},
    'Vec3': {'type':'array','items':{'type':'number'},'minItems':3,'maxItems':3},
    'QuatXyzw': {'type':'array','items':{'type':'number'},'minItems':4,'maxItems':4},
    'TrackingState': enum('initializing','tracked','degraded','lost','disconnected','unknown'),
    'Capability': enum('position','orientation','linear_velocity','angular_velocity','linear_acceleration','battery_fraction','charging'),
    'Presence': enum('present','absent','unknown'),
    'Evidence': enum('device','sample_sanity','none'),
    'TimestampKind': enum('sample','receive'),
    'Frame': enum('space','device'),
    'DerivativeEvidence': enum('measured','derived'),
}
# Field descriptor: name, type, nullable, optional. Public types do not expose JSON.
models = {}
def model(name, fields):
    models[name] = fields
    defs[name] = obj({n + ('?' if optional else ''): nullable(ref(t)) if null else ref(t)
                      for n,t,null,optional in fields})
def fields(**items):
    return [(n, t.rstrip('?'), t.endswith('?'), False) for n,t in items.items()]
defs['Bool'] = {'type':'boolean'}
model('Version', fields(major='UInt16',minor='UInt16'))
defs['Version']['properties']['major'] = {'type':'integer','const':1}
if v2:
    defs['Version']['properties']['major']['const'] = 2
    defs['Modality'] = enum('full', 'rotation_only', 'none')
model('CoordinateSpace', fields(id='Id',convention='Id',revision='UInt32'))
model('Battery', fields(fraction='Fraction?',charging='Bool?',timestamp_ns='U63'))
model('Derivative', fields(value='Vec3',frame='Frame',evidence='DerivativeEvidence'))
model('Validity', fields(position='Bool',orientation='Bool'))
model('Confidence', fields(position='Fraction',orientation='Fraction'))
model('Input', fields(device_id='Id',session_id='Uuid',sequence='U63'))
if v2: model('Input', fields(source_id='Id',device_id='Id',session_id='Uuid',sequence='U63',orientation_evidence='Evidence'))
defs['Capabilities'] = {'type':'array','items':ref('Capability'),'uniqueItems':True}
header = fields(version='Version',source_id='Id',session_id='Uuid',clock_id='Uuid',sequence='U63',timestamp_ns='U63',sent_at_ns='U63',timestamp_kind='TimestampKind')
pose = fields(position='Vec3?',orientation='QuatXyzw?',validity='Validity')
common = fields(tracking_state='TrackingState',coordinate_space='CoordinateSpace',capabilities='Capabilities')
messages = {'TrackerObservation':('monaka.observation','pose'), 'ObservationDeviceState':('monaka.observation','device_state'), 'MtpPose':('monaka.tracking','pose'), 'MtpTrackerState':('monaka.tracking','tracker_state')}
for name,(protocol,kind) in messages.items():
    mtp = protocol == 'monaka.tracking'
    f = header + fields(**{'tracker_id' if mtp else 'device_id':'Id'})
    if kind == 'pose':
        f += pose
        if not mtp: f += fields(orientation_evidence='Evidence')
        f += [(n,'Vec3' if mtp else 'Derivative',True,True) for n in ('linear_velocity','angular_velocity','linear_acceleration')]
        if mtp: f += fields(confidence='Confidence')
    else: f += fields(presence='Presence')
    f += common
    if v2:
        f += fields(modality='Modality')
        if mtp: f += fields(publisher_id='Id')
    if not mtp or kind != 'pose': f += fields(battery='Battery?')
    if mtp: f += fields(mapping_revision='UInt32')
    if mtp and kind == 'pose': f += fields(input='Input')
    model(name,f)
    for k,v in [('protocol',protocol),('type',kind)]:
        defs[name]['properties'][k] = {'type':'string','const':v}
        defs[name]['required'].append(k)
    if mtp:
        defs[name]['properties']['coordinate_space'] = obj({'id':ref('Id'),'convention':{'type':'string','const':'rh_y_up_neg_z_forward'},'revision':ref('UInt32')})

for file,names in [('tracker-observation',list(messages)[:2]),('monaka-tracking',list(messages)[2:])]:
    schema = {'$schema':'https://json-schema.org/draft/2020-12/schema', '$id':f'https://monaka.dev/schema/v{args.wire_major}/{file}.schema.json',
              '$comment':'C1 candidate SHA256 ' + hashlib.sha256(c1.encode()).hexdigest(),
              'oneOf':[ref(n) for n in names], '$defs':defs}
    put(f'schema/{file}.schema.json',json.dumps(schema,indent=2,ensure_ascii=False)+'\n')

if v2:
    import authority_definition as authority
    authority.define(defs, model, fields, ref, enum, messages, put, ROOT)

cpp_types = {'Id':'std::string','Uuid':'std::string','U63':'std::int64_t','I64':'std::int64_t','UInt32':'std::uint32_t','UInt16':'std::uint16_t','Fraction':'double','Bool':'bool','Vec3':'Vec3','QuatXyzw':'QuatXyzw','Capabilities':'std::vector<std::string>'}
kt_types = {'Id':'String','Uuid':'String','U63':'Long','I64':'Long','UInt32':'Long','UInt16':'Int','Fraction':'Double','Bool':'Boolean','Vec3':'List<Double>','QuatXyzw':'List<Double>','Capabilities':'List<String>'}
for n,d in defs.items():
    if 'enum' in d: cpp_types[n]='std::string'; kt_types[n]='String'
cpp = '#pragma once\n#include <array>\n#include <cstdint>\n#include <optional>\n#include <string>\n#include <variant>\n#include <vector>\nnamespace monaka::protocol::v1 {\nusing Vec3 = std::array<double,3>;\nusing QuatXyzw = std::array<double,4>;\n'
kt = 'package dev.monaka.protocol.v1\n\nsealed interface Envelope\n'
conversions = ''
ktcon = 'package dev.monaka.protocol.v1\nimport com.google.gson.*\n\n'
for name,ff in models.items():
    cpp += f'struct {name} {{\n'
    kt += f'data class {name}(\n'
    for n,t,null,opt in ff:
        ct = cpp_types.get(t,t)
        cpp += f'    {"std::optional<"+ct+">" if null else ct} {n}{{}};\n'
        kt += f'    val {n}: {kt_types.get(t,t)}{"?" if null else ""}{" = null" if opt else ""},\n'
    cpp += '};\n'
    kt += ')' + (' : Envelope' if name in messages else '') + '\n\n'
    conversions += f'void to_json(json& j, const {name}& v) {{ j=json::object();\n'
    ktcon += f'internal fun {name}.toJson(): JsonObject = JsonObject().also {{ j ->\n'
    for n,t,null,opt in ff:
        expr = f'std::to_string(v.{n})' if t in ('U63','I64') else f'v.{n}'
        if null:
            expr = f'std::to_string(*v.{n})' if t in ('U63','I64') else f'*v.{n}'
            conversions += f'    if(v.{n}) j["{n}"]={expr}; else j["{n}"]=nullptr;\n'
        else: conversions += f'    j["{n}"]={expr};\n'
        kexpr = f'{n}.toString()' if t in ('U63','I64') else n
        if t in models: kexpr=f'{n}{"?" if null else ""}.toJson()'
        else: kexpr=f'gson.toJsonTree({kexpr})'
        ktcon += f'    j.add("{n}", {kexpr})\n'
    if name in messages:
        p,k=messages[name]
        conversions+=f'    j["protocol"]="{p}"; j["type"]="{k}";\n'
        ktcon+=f'    j.addProperty("protocol", "{p}"); j.addProperty("type", "{k}")\n'
    conversions += '}\n'
    ktcon += '}\n'
    conversions += f'void from_json(const json& j, {name}& v) {{\n'
    ktcon += f'internal fun read{name}(j: JsonObject): {name} = {name}(\n'
    for n,t,null,opt in ff:
        ct=cpp_types.get(t,t)
        expr=f'std::stoll(j.at("{n}").get<std::string>())' if t in ('U63','I64') else f'j.at("{n}").get<{ct}>()'
        if null: conversions += f'    if(j.contains("{n}") && !j.at("{n}").is_null()) v.{n}={expr}; else v.{n}.reset();\n'
        else: conversions += f'    v.{n}={expr};\n'
        x=f'j.get("{n}")'
        if t in models: kexpr=f'read{t}({x}.asJsonObject)'
        elif t in ('Vec3','QuatXyzw'): kexpr=f'{x}.asJsonArray.map {{ it.asDouble }}'
        elif t=='Capabilities': kexpr=f'{x}.asJsonArray.map {{ it.asString }}'
        else: kexpr=f'{x}.as'+{'String':'String','Long':'Long','Int':'Int','Double':'Double','Boolean':'Boolean'}[kt_types[t]]
        if null: kexpr=f'if (!j.has("{n}") || {x}.isJsonNull) null else {kexpr}'
        ktcon+=f'    {n} = {kexpr},\n'
    conversions+='}\n'
    ktcon+=')\n'
cpp += 'using Envelope = std::variant<' + ','.join(messages) + '>;\n}\n'
put('cpp/include/monaka/protocol/v1/models.hpp',cpp)
put('cpp/src/models_json.inc',conversions)
put('jvm/src/main/kotlin/dev/monaka/protocol/v1/Models.kt',kt)
put('jvm/src/main/kotlin/dev/monaka/protocol/v1/ModelsJson.kt',ktcon)
compact=json.dumps({'$defs':defs},separators=(',',':'))
put('cpp/src/schema.inc', 'static const json schema = json::parse(R"SCHEMA('+compact+')SCHEMA");\n')
put('jvm/src/main/kotlin/dev/monaka/protocol/v1/Schema.kt','package dev.monaka.protocol.v1\nimport com.google.gson.JsonParser\ninternal val schema = JsonParser.parseString("""'+compact.replace('$',"${'$'}")+'""").asJsonObject\n')
if v2:
    # Share the parser implementation; only version dispatch and explicit semantic
    # policy differ. --check catches drift in the generated v2 codec as well.
    cpp_codec = (ROOT / 'cpp/src/codec.cpp').read_text(encoding='utf-8').replace('protocol/v1/', 'protocol/v2/').replace('major==1,', 'major==2,')
    cpp_codec = cpp_codec.replace('bool p=j["validity"]["position"], o=j["validity"]["orientation"];', '''bool p=j["validity"]["position"], o=j["validity"]["orientation"];
    const auto modality=j.at("modality");
    need(modality=="full" ? p&&o : modality=="rotation_only" ? !p&&o : !p&&!o,ErrorCode::InconsistentValidity,"modality");''')
    cpp_codec = cpp_codec.replace('if(j.at("type")!="pose") return;', '''if(j.contains("input")) need(j["input"]["source_id"]==j["source_id"],ErrorCode::InconsistentValidity,"input.source_id");
    if(j.at("type")!="pose") {
        if(j["presence"]=="absent" || (j["tracking_state"]!="tracked" && j["tracking_state"]!="degraded"))
            need(j["modality"]=="none",ErrorCode::InconsistentValidity,"inactive state modality");
        return;
    }''')
    cpp_codec = authority.cpp_codec(cpp_codec)
    put('cpp/src/codec.cpp', cpp_codec)
    put('cpp/include/monaka/protocol/v1/codec.hpp', (ROOT / 'cpp/include/monaka/protocol/v1/codec.hpp').read_text().replace('protocol/v1/', 'protocol/v2/'))
    kt_codec = (ROOT / 'jvm/src/main/kotlin/dev/monaka/protocol/v1/MonakaCodec.kt').read_text(encoding='utf-8').replace('major==1.0,', 'major==2.0,')
    kt_codec = kt_codec.replace('val p = valid["position"].asBoolean; val o = valid["orientation"].asBoolean', '''val p = valid["position"].asBoolean; val o = valid["orientation"].asBoolean
    need(when(j["modality"].asString) { "full" -> p&&o; "rotation_only" -> !p&&o; else -> !p&&!o },ErrorCode.InconsistentValidity,"modality")''')
    kt_codec = kt_codec.replace('if(j["type"].asString!="pose") return', '''if(j.has("input")) need(j["input"].asJsonObject["source_id"]==j["source_id"],ErrorCode.InconsistentValidity,"input.source_id")
    if(j["type"].asString!="pose") {
        if(j["presence"].asString=="absent" || j["tracking_state"].asString !in listOf("tracked","degraded"))
            need(j["modality"].asString=="none",ErrorCode.InconsistentValidity,"inactive state modality")
        return
    }''')
    kt_codec = authority.kt_codec(kt_codec)
    put('jvm/src/main/kotlin/dev/monaka/protocol/v1/MonakaCodec.kt', kt_codec)
